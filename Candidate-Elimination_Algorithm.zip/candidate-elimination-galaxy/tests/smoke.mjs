import assert from 'node:assert/strict'
import { datasetModel, normalizeRows, classifyInstance } from '../src/algorithm/candidateElimination.js'

const enjoySport = [
  { Sky: 'Sunny', AirTemp: 'Warm', Humidity: 'Normal', Wind: 'Strong', Water: 'Warm', Forecast: 'Same', EnjoySport: 'Yes' },
  { Sky: 'Sunny', AirTemp: 'Warm', Humidity: 'High', Wind: 'Strong', Water: 'Warm', Forecast: 'Same', EnjoySport: 'Yes' },
  { Sky: 'Rainy', AirTemp: 'Cold', Humidity: 'High', Wind: 'Strong', Water: 'Warm', Forecast: 'Change', EnjoySport: 'No' },
  { Sky: 'Sunny', AirTemp: 'Warm', Humidity: 'High', Wind: 'Strong', Water: 'Cool', Forecast: 'Change', EnjoySport: 'Yes' }
]

const model = datasetModel(normalizeRows(enjoySport))
const final = model.steps.at(-1)

assert.deepEqual(model.S, [['Sunny', 'Warm', '?', 'Strong', '?', '?']])
assert.deepEqual(model.G, [
  ['Sunny', '?', '?', '?', '?', '?'],
  ['?', 'Warm', '?', '?', '?', '?']
])
assert.equal(final.versionSpace.length, 6)
assert.equal(classifyInstance(model, ['Sunny', 'Warm', 'Normal', 'Strong', 'Warm', 'Same'], final.versionSpace).state, 'accepted')
assert.equal(classifyInstance(model, ['Rainy', 'Cold', 'High', 'Strong', 'Warm', 'Change'], final.versionSpace).state, 'rejected')
assert.equal(classifyInstance(model, ['Sunny', 'Cold', 'Normal', 'Weak', 'Cool', 'Same'], final.versionSpace).state, 'ambiguous')
assert.ok(['Yes', 'No'].includes(classifyInstance(model, ['Sunny', 'Cold', 'Normal', 'Weak', 'Cool', 'Same'], final.versionSpace).majorityLabel))

const noisyRows = [...model.rows, { ...model.rows[0], id: 5, target: 'No' }]
const noisy = datasetModel({ ...normalizeRows(noisyRows.map(row => ({
  Sky: row.features[0], AirTemp: row.features[1], Humidity: row.features[2], Wind: row.features[3], Water: row.features[4], Forecast: row.features[5], EnjoySport: row.target
}))) })
assert.equal(noisy.steps.at(-1).versionSpace.length, 0)
assert.equal(noisy.S.length, 0)
assert.equal(noisy.G.length, 0)

console.log('Candidate-Elimination smoke tests: PASS')
