# Start Here — VS Code (Windows)

## Requirements
- Node.js 22.13+ (Node 26 is supported by this launcher)
- Python 3.10+
- VS Code

## Install
Open the extracted `candidate-elimination-galaxy` folder in VS Code and run:

```bash
npm install
```

## Start the complete project
```bash
npm run dev
```

### Windows launcher fix
The project does **not** spawn `npm.cmd` with `shell:false`. That can produce:

```text
Error: spawn EINVAL
```

on Windows/Node versions such as Node 26.8.1. The launcher now starts Vite directly through the current Node executable and starts the Python Matplotlib service separately.

## What starts
- Vite/React frontend
- Local Python + Matplotlib visualization server at `http://127.0.0.1:8765`

Both are stopped when you press `Ctrl+C` in the terminal.

## Optional checks
```bash
npm run test
npm run build
```

## Automatic Matplotlib pipeline
Every imported/loaded dataset is cleaned in the React app. The cleaned rows are sent to the local Matplotlib service, which creates an automatic 2D visualization and S/G boundary snapshot. Changing the learning step regenerates the figure.
