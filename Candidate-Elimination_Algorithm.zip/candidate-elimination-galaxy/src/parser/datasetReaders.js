import Papa from 'papaparse'
import * as XLSX from 'xlsx'

function cleanCell(value) {
  if (value === null || value === undefined) return ''
  return String(value).replace(/\u00a0/g, ' ').trim()
}

export function detectDelimiter(text) {
  const candidates = [',', '\\t', '|', ';']
  const sample = text.split(/\r?\n/).filter(Boolean).slice(0, 8)
  let best = ','
  let bestScore = -1
  for (const delimiter of candidates) {
    const counts = sample.map(line => line.split(delimiter).length - 1).filter(Boolean)
    if (!counts.length) continue
    const score = Math.min(...counts) * 10 + counts.length
    if (score > bestScore) {
      best = delimiter
      bestScore = score
    }
  }
  return best
}

export function textToRows(text) {
  const normalized = String(text ?? '')
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .replace(/\u0000/g, '')
  if (normalized.trim().split('\n').filter(Boolean).length < 2) {
    throw new Error('The document does not contain enough tabular rows.')
  }

  const delimiter = detectDelimiter(normalized)
  const parsed = Papa.parse(normalized, {
    header: true,
    skipEmptyLines: true,
    delimiter,
    transformHeader: h => cleanCell(h),
    transform: value => cleanCell(value)
  })
  const fatal = parsed.errors?.find(error => ['Delimiter', 'Quotes', 'FieldMismatch'].includes(error.type))
  if (fatal) throw new Error(fatal.message)
  if (!parsed.data?.length) throw new Error('No rows were extracted from the document.')
  return parsed.data
}

export async function parseCsvFile(file) {
  const parsed = Papa.parse(await file.text(), {
    header: true,
    skipEmptyLines: 'greedy',
    transformHeader: h => cleanCell(h),
    transform: value => cleanCell(value)
  })
  const fatal = parsed.errors?.find(error => ['Delimiter', 'Quotes', 'FieldMismatch'].includes(error.type))
  if (fatal) throw new Error(fatal.message)
  return parsed.data
}

export async function parseExcelFile(file) {
  const workbook = XLSX.read(await file.arrayBuffer(), { type: 'array', cellDates: true })
  const firstSheet = workbook.Sheets[workbook.SheetNames[0]]
  if (!firstSheet) throw new Error('No worksheet was found in the Excel file.')
  return XLSX.utils.sheet_to_json(firstSheet, { defval: '' })
}

export function extractStructuredTables(ast) {
  const tables = []
  const walk = node => {
    if (!node) return
    if (Array.isArray(node)) { node.forEach(walk); return }
    if (typeof node !== 'object') return
    if (node.type === 'table') tables.push(node)
    if (node.children) walk(node.children)
    if (node.content) walk(node.content)
  }
  walk(ast?.content)
  return tables
}

function tableNodeToRows(table) {
  const rowNodes = (table.children ?? []).filter(node => node?.type === 'row')
  const matrix = rowNodes.map(row => (row.children ?? [])
    .filter(cell => cell?.type === 'cell')
    .map(cell => cleanCell(cell.text ?? '')))
  if (matrix.length < 2) return []
  const width = Math.max(...matrix.map(row => row.length))
  const headers = Array.from({ length: width }, (_, i) => matrix[0][i] || `Feature ${i + 1}`)
  return matrix.slice(1).map(row => {
    const record = {}
    headers.forEach((header, i) => { record[header] = row[i] ?? '' })
    return record
  })
}

export async function parseOfficeFile(file) {
  const { OfficeParser } = await import('officeparser')
  const ast = await OfficeParser.parseOffice(new Uint8Array(await file.arrayBuffer()), {
    pdfParserConfig: { extractTextColor: false },
    pdfWorkerSrc: new URL('pdfjs-dist/build/pdf.worker.min.mjs', import.meta.url).toString()
  })

  const tables = extractStructuredTables(ast)
  for (const table of tables) {
    const rows = tableNodeToRows(table)
    if (rows.length) return rows
  }

  const textResult = await ast.to('text')
  const text = typeof textResult === 'string' ? textResult : textResult?.value
  if (!text) throw new Error('The document was read, but no text/table rows were extracted.')
  return textToRows(text)
}

export async function parseWordLegacy(file) {
  const { read, to_text } = await import('@transkripid/document-ocr')
  const doc = await read(new Uint8Array(await file.arrayBuffer()), { maxDocumentBytes: 64 * 1024 * 1024 })
  return textToRows(to_text(doc))
}

export async function parseDatasetFile(file) {
  const ext = file.name.toLowerCase().split('.').pop()
  switch (ext) {
    case 'csv': return { rows: await parseCsvFile(file), format: 'CSV' }
    case 'xls':
    case 'xlsx': return { rows: await parseExcelFile(file), format: ext.toUpperCase() }
    case 'doc': return { rows: await parseWordLegacy(file), format: 'Word DOC' }
    case 'docx':
    case 'pdf':
    case 'pptx':
    case 'ppt':
    case 'odt':
    case 'ods':
    case 'odp':
    case 'rtf':
      return { rows: await parseOfficeFile(file), format: ext.toUpperCase() }
    case 'txt':
    case 'tsv':
    case 'tab':
    case 'md':
      return { rows: textToRows(await file.text()), format: ext.toUpperCase() }
    case 'json': {
      const json = JSON.parse(await file.text())
      if (!Array.isArray(json)) throw new Error('JSON dataset must be an array of objects.')
      return { rows: json, format: 'JSON' }
    }
    default:
      throw new Error('Unsupported format. Use CSV, XLS/XLSX, DOC/DOCX, PDF, TXT/TSV, JSON, PPT/PPTX, ODT/ODS/ODP, or RTF.')
  }
}
