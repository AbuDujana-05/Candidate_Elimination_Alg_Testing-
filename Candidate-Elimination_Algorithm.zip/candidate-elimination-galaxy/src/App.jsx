import { useEffect, useMemo, useRef, useState } from 'react'
import Papa from 'papaparse'
import Galaxy from './components/Galaxy/Galaxy'
import HypothesisMap, { BoundaryEvolution } from './components/Visualization/HypothesisMap'
import MatplotlibMap from './components/Visualization/MatplotlibMap'
import { classifyInstance, datasetModel, flipLabel, hypothesisKey, normalizeRows, NULL_VALUE } from './algorithm/candidateElimination'
import { parseDatasetFile } from './parser/datasetReaders'

const ENJOY_HEADERS = ['Sky', 'AirTemp', 'Humidity', 'Wind', 'Water', 'Forecast', 'EnjoySport']
const DEMO_ENJOY = [
  { Sky: 'Sunny', AirTemp: 'Warm', Humidity: 'Normal', Wind: 'Strong', Water: 'Warm', Forecast: 'Same', EnjoySport: 'Yes' },
  { Sky: 'Sunny', AirTemp: 'Warm', Humidity: 'High', Wind: 'Strong', Water: 'Warm', Forecast: 'Same', EnjoySport: 'Yes' },
  { Sky: 'Rainy', AirTemp: 'Cold', Humidity: 'High', Wind: 'Strong', Water: 'Warm', Forecast: 'Change', EnjoySport: 'No' },
  { Sky: 'Sunny', AirTemp: 'Warm', Humidity: 'High', Wind: 'Strong', Water: 'Cool', Forecast: 'Change', EnjoySport: 'Yes' }
]

const ACCEPTED_FORMATS = '.csv,.xlsx,.xls,.pdf,.doc,.docx,.txt,.tsv,.tab,.json,.rtf,.ppt,.pptx,.odt,.ods,.odp,.md'

function hypothesisText(h, names) {
  return `<${h.map((value, i) => `${names[i]}=${value === NULL_VALUE ? '∅' : value}`).join(', ')}>`
}

function formatSize(bytes) {
  if (!bytes) return '0 KB'
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}

function Stat({ label, value, accent }) {
  return <div className={`stat ${accent ? `stat-${accent}` : ''}`}><div className="stat-value">{value}</div><div className="stat-label">{label}</div></div>
}

function Pill({ children, tone = '' }) { return <span className={`pill ${tone}`}>{children}</span> }

function BoundaryCard({ title, hypotheses, names, tone, help }) {
  return (
    <section className={`panel glass boundary-card ${tone}`}>
      <div className="panel-head">
        <div><div className="eyebrow">{title}</div><h2>{tone === 'specific' ? 'Specific Boundary S' : 'General Boundary G'}</h2></div>
        <Pill tone={tone === 'specific' ? 'cyan' : 'purple'}>{hypotheses.length} {hypotheses.length === 1 ? 'hypothesis' : 'hypotheses'}</Pill>
      </div>
      <p className="muted">{help}</p>
      <div className="hypothesis-list">
        {hypotheses.length === 0
          ? <div className="empty-boundary">∅ &nbsp; boundary collapsed</div>
          : hypotheses.map((h, i) => <div className="hypothesis" key={`${hypothesisKey(h)}-${i}`}><span className="h-index">{i + 1}</span><code>{hypothesisText(h, names)}</code></div>)}
      </div>
    </section>
  )
}

function formatName(format) {
  return format === 'DOCX' ? 'Word' : format === 'XLSX' || format === 'XLS' ? 'Excel' : format
}

export default function App() {
  const inputRef = useRef(null)
  const dragCounter = useRef(0)
  const [model, setModel] = useState(null)
  const [activeStep, setActiveStep] = useState(0)
  const [playing, setPlaying] = useState(false)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [fileInfo, setFileInfo] = useState(null)
  const [noiseInjected, setNoiseInjected] = useState(false)
  const [testValues, setTestValues] = useState([])
  const [selectedTab, setSelectedTab] = useState('matplotlib')
  const [showVS, setShowVS] = useState(false)
  const [dragging, setDragging] = useState(false)

  const active = model?.steps?.[activeStep] ?? null
  const activeVS = active?.versionSpace ?? []

  useEffect(() => {
    if (!model) return
    setPlaying(false)
  }, [model])

  useEffect(() => {
    if (!playing || !model) return undefined
    const timer = window.setInterval(() => {
      setActiveStep(prev => {
        if (prev >= model.steps.length - 1) {
          setPlaying(false)
          return prev
        }
        return prev + 1
      })
    }, 1100)
    return () => window.clearInterval(timer)
  }, [playing, model])

  useEffect(() => {
    // Launch directly into a visible teaching example so the app is not an empty black screen.
    const cleaned = normalizeRows(DEMO_ENJOY)
    const demoModel = datasetModel(cleaned)
    setModel(demoModel)
    setActiveStep(0)
    const demoPositive = demoModel.rows.find(row => String(row.target).trim().toLowerCase() === String(demoModel.targetLabels.positiveLabel).trim().toLowerCase())
    setTestValues(demoPositive?.features ?? Array(demoModel.featureNames.length).fill(''))
    setFileInfo({ name: 'EnjoySport.csv', format: 'CSV', size: 0, demo: true })
  }, [])

  const health = useMemo(() => {
    if (!active) return null
    return activeVS.length > 0
      ? { state: 'healthy', text: `${activeVS.length.toLocaleString()} consistent hypotheses remain.` }
      : { state: 'collapsed', text: 'No hypothesis satisfies every observed example.' }
  }, [active, activeVS])

  const setRows = async (rawRows, info) => {
    setBusy(true)
    setError('')
    try {
      const cleaned = normalizeRows(rawRows)
      if (!cleaned.rows.length) throw new Error('No usable rows were found. The last column must contain target labels.')
      if (!cleaned.featureNames.length) throw new Error('A dataset needs at least one feature column plus a target column.')
      const built = datasetModel(cleaned)
      built.datasetName = info?.name || 'Imported dataset'
      setModel(built)
      setActiveStep(0)
      setNoiseInjected(false)
      setShowVS(false)
      setTestValues(Array(built.featureNames.length).fill(''))
      setFileInfo(info)
      window.scrollTo({ top: 0, behavior: 'smooth' })
    } catch (e) {
      setError(e?.message || String(e))
    } finally {
      setBusy(false)
    }
  }

  const handleFile = async file => {
    if (!file) return
    setBusy(true); setError('')
    try {
      const result = await parseDatasetFile(file)
      await setRows(result.rows, { name: file.name, format: result.format, size: file.size, demo: false })
    } catch (e) {
      setBusy(false)
      setError(`${file.name}: ${e?.message || String(e)}`)
    }
  }

  const handleDrop = async e => {
    e.preventDefault(); e.stopPropagation(); dragCounter.current = 0; setDragging(false)
    await handleFile(e.dataTransfer.files?.[0])
  }

  const loadEnjoy = () => setRows(DEMO_ENJOY, { name: 'EnjoySport.csv', format: 'CSV', size: 0, demo: true })

  const loadDemoFile = async (path, label) => {
    setBusy(true); setError('')
    try {
      const response = await fetch(path)
      if (!response.ok) throw new Error(`Could not fetch demo (${response.status}).`)
      const text = await response.text()
      const parsed = Papa.parse(text, { header: true, skipEmptyLines: true })
      await setRows(parsed.data, { name: label, format: 'CSV', size: new Blob([text]).size, demo: true })
    } catch (e) {
      setBusy(false); setError(e?.message || String(e))
    }
  }

  const injectNoise = () => {
    if (!model) return
    if (noiseInjected) {
      const originalRows = model.rows.slice(0, -1)
      const rebuilt = datasetModel({ ...normalizeRows(originalRows.map(r => Object.fromEntries(model.headers.map((header, i) => [header, i < model.featureNames.length ? r.features[i] : r.target])))) })
      setModel(rebuilt); setActiveStep(rebuilt.steps.length - 1); setNoiseInjected(false); setShowVS(false); setTestValues(Array(rebuilt.featureNames.length).fill(''))
      return
    }
    const source = model.rows.find(row => String(row.target).toLowerCase() === String(model.targetLabels.positiveLabel).toLowerCase())
    if (!source) return
    const noisy = { ...source, id: model.rows.length + 1, target: flipLabel(source.target, model.targetLabels), noise: true }
    const rebuilt = datasetModel({ ...model, rows: [...model.rows, noisy], stats: { ...model.stats, rowsRead: model.stats.rowsRead + 1, rowsKept: model.stats.rowsKept + 1 } })
    setModel(rebuilt); setActiveStep(rebuilt.steps.length - 1); setNoiseInjected(true); setShowVS(false); setTestValues(Array(rebuilt.featureNames.length).fill(''))
  }

  const finalStep = model?.steps?.[model.steps.length - 1] ?? null
  const finalVS = finalStep?.versionSpace ?? []
  const classification = model && active && testValues.length === model.featureNames.length && testValues.every(Boolean)
    ? classifyInstance(model, testValues, finalVS)
    : null

  const applyTrainingExample = row => {
    if (!row || !model) return
    setTestValues([...row.features])
    setActiveStep(model.steps.length - 1)
  }

  const exportVS = () => {
    if (!active || !model) return
    const blob = new Blob([JSON.stringify({
      dataset: fileInfo?.name,
      step: active.step,
      featureNames: model.featureNames,
      S: active.S,
      G: active.G,
      versionSpace: activeVS
    }, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url; link.download = `candidate-elimination-step-${active.step}.json`; link.click(); URL.revokeObjectURL(url)
  }

  return (
    <div className="app-shell">
      <div className="galaxy-layer" aria-hidden="true">
        <Galaxy mouseRepulsion={true} mouseInteraction={true} density={1.5} glowIntensity={0.5} saturation={0.8} hueShift={240} repulsionStrength={1.5} transparent={true} twinkleIntensity={0.55} />
      </div>
      <div className="star-wash" /><div className="ambient ambient-cyan" /><div className="ambient ambient-purple" />

      <header className="topbar glass">
        <div className="brand"><div className="brand-mark">CE</div><div><div className="brand-name">Candidate-Elimination</div><div className="brand-sub">Version Space Visual Lab</div></div></div>
        <div className="topbar-meta"><span className="live-dot" />LIVE VISUALIZER <span>•</span> React + Vite</div>
      </header>

      <main className="page">
        <section className="hero">
          <div className="hero-copy">
            <Pill tone="accent">◉ INTERACTIVE MACHINE LEARNING</Pill>
            <h1>Candidate-Elimination Algorithm<br /><span>Testing</span></h1>
            <div className="authors">Done by <strong>Abu Dujana</strong>, <strong>Nithish</strong> &amp; <strong>Pravina</strong></div>
            <p className="hero-text">A visual, hands-on Candidate-Elimination laboratory. Load a dataset, replay every learning step, see S and G move, and challenge the surviving hypotheses with your own input.</p>
            <div className="hero-badges"><span>06-step boundary logic</span><span>Live hypothesis map</span><span>Noise collapse demo</span></div>
          </div>

          <div className={`upload-card glass ${dragging ? 'dragging' : ''}`} onDragEnter={e => { e.preventDefault(); dragCounter.current += 1; setDragging(true) }} onDragOver={e => e.preventDefault()} onDragLeave={e => { e.preventDefault(); dragCounter.current -= 1; if (dragCounter.current <= 0) setDragging(false) }} onDrop={handleDrop}>
            <div className="upload-top"><div className="upload-glow">↥</div><div><div className="upload-title">Bring your dataset to life</div><div className="upload-sub">Drop a file or browse your computer</div></div></div>
            <button className="btn primary big" onClick={() => inputRef.current?.click()} disabled={busy}>{busy ? 'Parsing dataset…' : 'Choose Dataset'}</button>
            <input ref={inputRef} type="file" accept={ACCEPTED_FORMATS} hidden onChange={e => handleFile(e.target.files?.[0])} />
            <div className="format-cloud"><span>CSV</span><span>XLSX</span><span>XLS</span><span>PDF</span><span>DOCX</span><span>DOC</span><span>JSON</span><span>TXT/TSV</span><span>PPTX</span><span>ODT/ODS</span></div>
            <div className="demo-row"><button className="btn demo cyan-btn" onClick={loadEnjoy}>Open EnjoySport</button><button className="btn demo" onClick={() => loadDemoFile('/datasets/Laptop_25.csv', 'Laptop 25-row')}>Laptop 25</button><button className="btn demo" onClick={() => loadDemoFile('/datasets/Laptop_1000.csv', 'Laptop 1000-row')}>Laptop 1000</button></div>
          </div>
        </section>

        {fileInfo && model && <div className="loaded-chip glass"><span className="loaded-icon">✓</span><div><b>{fileInfo.name}</b><small>{formatName(fileInfo.format)} • {fileInfo.demo ? 'built-in demo' : formatSize(fileInfo.size)} • last column = target</small></div><button className="text-btn" onClick={() => inputRef.current?.click()}>Replace</button></div>}
        {error && <div className="alert error glass"><span className="alert-symbol">!</span><div><b>Couldn’t build the learning set</b><div>{error}</div></div></div>}

        {model && active && (
          <>
            <section className="stats-grid">
              <Stat label="Training examples" value={model.rows.length} accent="cyan" />
              <Stat label="Features / concepts" value={model.featureNames.length} />
              <Stat label="Hypotheses in H" value={model.hypothesisCount.toLocaleString()} accent="purple" />
              <Stat label="Current version space" value={activeVS.length.toLocaleString()} accent={health.state === 'collapsed' ? 'danger' : 'green'} />
            </section>

            <section className="control-bar glass">
              <div className="control-main">
                <button className={`play-btn ${playing ? 'active' : ''}`} aria-label={playing ? 'Pause replay' : 'Start replay'} onClick={() => { if (!playing && activeStep >= model.steps.length - 1) setActiveStep(0); setPlaying(v => !v) }}><span className="play-icon">{playing ? '❚❚' : '▶'}</span><span className="play-text">{playing ? 'Pause' : 'Start'}</span></button>
                <div className="step-range"><div className="step-label"><b>Replay the learner</b><span>Step {active.step} / {model.steps.length - 1}</span></div><input type="range" min="0" max={model.steps.length - 1} value={activeStep} onChange={e => { setPlaying(false); setActiveStep(Number(e.target.value)) }} /></div>
                <button className="btn ghost" onClick={() => { setActiveStep(0); setPlaying(false) }}>Reset</button>
              </div>
              <div className="control-right"><Pill tone={active.action === 'positive' ? 'green' : active.action === 'negative' ? 'yellow' : 'cyan'}>{active.action === 'initialize' ? 'INITIALIZE H' : `${active.action.toUpperCase()} EXAMPLE`}</Pill><button className="btn warn" onClick={injectNoise}>{noiseInjected ? '↺ Remove Noise' : '⚠ Inject Noise'}</button></div>
            </section>

            <section className="trace-panel glass">
              <div className="panel-head"><div><div className="eyebrow">LEARNING TRACE</div><h2>Click any step. Watch the boundaries react.</h2></div><Pill tone={health.state === 'collapsed' ? 'red' : 'green'}>{health.text}</Pill></div>
              <div className="trace-steps">{model.steps.map(step => <button key={step.step} className={`trace-step ${activeStep === step.step ? 'active' : ''} ${step.versionSpace.length === 0 ? 'collapsed' : ''}`} onClick={() => { setPlaying(false); setActiveStep(step.step) }}><span>{step.step}</span><b>{step.step === 0 ? 'Start' : `Ex ${step.step}`}</b><small>{step.step === 0 ? 'S + G' : step.row.target === model.targetLabels.positiveLabel ? 'Positive' : 'Negative'}</small><em>{step.versionSpace.length.toLocaleString()}</em></button>)}</div>
              <div className="trace-detail"><div className="detail-line"><Pill tone={active.action === 'positive' ? 'green' : active.action === 'negative' ? 'yellow' : 'cyan'}>{active.action.toUpperCase()}</Pill><span>{active.description}</span></div>{active.row && <div className="observed-row"><span className="observed-label">Example {active.step}</span>{active.row.features.map((value, i) => <div key={model.featureNames[i]}><small>{model.featureNames[i]}</small><b>{value}</b></div>)}<div className="observed-target"><small>{model.targetName}</small><b>{active.row.target}</b></div></div>}</div>
            </section>

            <section className="visual-tabs glass">
              <button className={selectedTab === 'matplotlib' ? 'selected' : ''} onClick={() => setSelectedTab('matplotlib')}>◈ Matplotlib Map</button>
              <button className={selectedTab === 'visual' ? 'selected' : ''} onClick={() => setSelectedTab('visual')}>✦ Hypothesis Map</button>
              <button className={selectedTab === 'evolution' ? 'selected' : ''} onClick={() => setSelectedTab('evolution')}>⌁ Boundary Evolution</button>
              <button className={selectedTab === 'data' ? 'selected' : ''} onClick={() => setSelectedTab('data')}>▦ Data Preview</button>
            </section>

            <div className={selectedTab === 'matplotlib' ? '' : 'tab-panel-hidden'}><MatplotlibMap model={model} active={active} /></div>
            {selectedTab === 'visual' && <HypothesisMap hypotheses={activeVS} S={active.S} G={active.G} names={model.featureNames} steps={model.steps} activeStep={activeStep} />}
            {selectedTab === 'evolution' && <BoundaryEvolution steps={model.steps} names={model.featureNames} />}
            {selectedTab === 'data' && <section className="panel glass data-preview"><div className="panel-head"><div><div className="eyebrow">CLEANED TRAINING SET</div><h2>What the algorithm is actually learning from</h2></div><Pill>{model.stats.rowsKept} rows</Pill></div><div className="table-wrap"><table><thead><tr>{model.headers.map(h => <th key={h}>{h}</th>)}</tr></thead><tbody>{model.rows.slice(0, 12).map(row => <tr key={row.id}>{row.features.map((value, i) => <td key={`${row.id}-${i}`}>{value}</td>)}<td><span className={`target-cell ${String(row.target).toLowerCase() === String(model.targetLabels.positiveLabel).toLowerCase() ? 'positive' : 'negative'}`}>{row.target}</span></td></tr>)}</tbody></table></div></section>}

            {noiseInjected && health.state === 'collapsed' && <section className="noise-collapse glass"><div className="collapse-icon">×</div><div><div className="eyebrow danger-text">WHY CANDIDATE-ELIMINATION BREAKS HERE</div><h2>One feature vector. Two opposite labels. Zero consistent hypotheses.</h2><p>The injected row is an exact duplicate of a positive example, but its target is flipped to negative. A deterministic hypothesis cannot classify the same feature vector both ways, so the mathematically defined version space becomes empty.</p><div className="collapse-equation"><span>S</span><b>∅</b><span>+</span><span>G</span><b>∅</b><span>→</span><strong>VS = ∅</strong></div></div></section>}

            <section className="boundaries-grid"><BoundaryCard title={`STEP ${active.step}`} tone="specific" hypotheses={active.S} names={model.featureNames} help="The most specific surviving boundary. Positive examples push S upward toward generalizations." /><BoundaryCard title={`STEP ${active.step}`} tone="general" hypotheses={active.G} names={model.featureNames} help="The most general surviving boundary. Negative examples force G downward through specializations." /></section>



            <section className="panel glass tester-panel">
              <div className="tester-title-row"><div><div className="eyebrow">TEST IT YOURSELF</div><h2>Can the current version space classify this?</h2></div><Pill tone="cyan">Exact consensus • final VS</Pill></div>
              <p className="muted">Testing uses the <b>final learned version space</b> so the result reflects the completed training set. During a replay, the visualization above can still show any intermediate step.</p>
              <div className="quick-tests">
                <span className="quick-label">Quick checks:</span>
                <button className="btn demo cyan-btn" onClick={() => applyTrainingExample(model.rows.find(row => String(row.target).trim().toLowerCase() === String(model.targetLabels.positiveLabel).trim().toLowerCase()))}>Use positive example</button>
                <button className="btn demo" onClick={() => applyTrainingExample(model.rows.find(row => String(row.target).trim().toLowerCase() === String(model.targetLabels.negativeLabel).trim().toLowerCase()))}>Use negative example</button>
                <button className="btn demo" onClick={() => setActiveStep(model.steps.length - 1)}>Jump to final model</button>
              </div>
              <div className="tester-grid">{model.featureNames.map((name, i) => <label className="field" key={name}><span>{name}</span><select value={testValues[i] ?? ''} onChange={e => { const next = [...testValues]; next[i] = e.target.value; setTestValues(next) }}><option value="">Select {name}…</option>{model.domains[i].map(v => <option value={v} key={v}>{v}</option>)}</select></label>)}</div>
              {classification && <div className={`classification ${classification.state}`}><div className="classification-badge">{classification.state === 'accepted' ? '✓' : classification.state === 'rejected' ? '×' : classification.state === 'collapsed' ? '∅' : '?'}</div><div><div className="eyebrow">VERSION-SPACE DECISION</div><h3>{classification.state === 'collapsed' ? 'Version space is empty' : classification.label}</h3><p>{classification.state === 'accepted' ? `All ${classification.total.toLocaleString()} surviving hypotheses agree on ${classification.label}.` : classification.state === 'rejected' ? `All ${classification.total.toLocaleString()} surviving hypotheses agree on ${classification.label}.` : classification.state === 'ambiguous' ? `${classification.positiveVotes.toLocaleString()} hypotheses predict positive; ${classification.negativeVotes.toLocaleString()} predict negative. Exact Candidate-Elimination therefore reports Ambiguous. Majority-vote teaching aid: ${classification.majorityLabel}.` : 'Contradictory training examples eliminated every consistent hypothesis.'}</p></div></div>}
            </section>

            <section className="panel glass exact-panel"><div className="panel-head"><div><div className="eyebrow">EXACT VERSION SPACE</div><h2>Inspect the hypotheses behind the visualization</h2></div><div className="head-actions"><Pill>{activeVS.length.toLocaleString()} survivors</Pill><button className="btn ghost" onClick={() => setShowVS(v => !v)}>{showVS ? 'Hide' : 'Show'} hypotheses</button><button className="btn ghost" onClick={exportVS}>Export JSON</button></div></div>{showVS && <div className="vs-grid">{activeVS.slice(0, 400).map((h, i) => <code key={`${hypothesisKey(h)}-${i}`}>H{i + 1}: {hypothesisText(h, model.featureNames)}</code>)}{activeVS.length > 400 && <div className="vs-note">Preview shows 400 of {activeVS.length.toLocaleString()}; JSON export contains the complete exact set.</div>}{activeVS.length === 0 && <div className="empty-boundary">∅ No consistent hypotheses remain.</div>}</div>}</section>
          </>
        )}
      </main>

      <footer className="footer"><span>Candidate-Elimination • Interactive educational prototype</span><span>Galaxy background • OGL/WebGL • Glass UI</span></footer>
    </div>
  )
}
