import { useMemo, useState } from 'react'
import { hypothesisKey, WILDCARD } from '../../algorithm/candidateElimination'

const hash = value => {
  let h = 2166136261
  for (let i = 0; i < value.length; i++) h = Math.imul(h ^ value.charCodeAt(i), 16777619)
  return (h >>> 0) / 4294967295
}

export default function HypothesisMap({ hypotheses, S, G, names, steps = [], activeStep = 0 }) {
  const [selected, setSelected] = useState(null)
  const maxNodes = 260

  const points = useMemo(() => {
    // Keep hypotheses from earlier steps visible as a soft trail.
    // This prevents the map from feeling like it is erasing its history.
    const historyMap = new Map()
    steps.slice(0, activeStep + 1).forEach((step, stepIndex) => {
      step.versionSpace.forEach(h => {
        const key = hypothesisKey(h)
        const current = historyMap.get(key)
        historyMap.set(key, {
          h,
          firstStep: current?.firstStep ?? stepIndex,
          lastSeen: stepIndex
        })
      })
    })

    const source = historyMap.size ? [...historyMap.values()] : hypotheses.map(h => ({ h, firstStep: activeStep, lastSeen: activeStep }))
    source.sort((a, b) => {
      const aw = a.h.filter(v => v === WILDCARD).length
      const bw = b.h.filter(v => v === WILDCARD).length
      return aw - bw || hypothesisKey(a.h).localeCompare(hypothesisKey(b.h))
    })

    const visible = source.length <= maxNodes
      ? source
      : source.filter((_, i) => i % Math.ceil(source.length / maxNodes) === 0).slice(0, maxNodes)

    return visible.map((item, i) => {
      const h = item.h
      const wildcards = h.filter(v => v === WILDCARD).length
      const generality = wildcards / Math.max(1, names.length)
      const jitter = hash(hypothesisKey(h))
      const key = hypothesisKey(h)
      return {
        h,
        x: 36 + generality * 720,
        y: 54 + jitter * 212,
        key,
        wildcardCount: wildcards,
        special: S.some(s => hypothesisKey(s) === key),
        general: G.some(g => hypothesisKey(g) === key),
        current: hypotheses.some(currentH => hypothesisKey(currentH) === key),
        firstStep: item.firstStep,
        lastSeen: item.lastSeen,
        i
      }
    })
  }, [hypotheses, S, G, names.length, steps, activeStep])

  const selectedPoint = selected ? points.find(p => p.key === selected) : null
  const displayH = h => `<${h.map(v => v === '?' ? '?' : v === '∅' ? '∅' : v).join(', ')}>`

  return (
    <section className="visual-card glass">
      <div className="visual-head">
        <div>
          <div className="eyebrow">LIVE VISUALIZATION</div>
          <h2>Hypothesis space map</h2>
          <p>Every visited hypothesis stays on the map as a soft trail. The current version space stays bright. Left = specific, right = general.</p>
        </div>
        <div className="visual-legend">
          <span><i className="legend-dot ordinary" />Current version space</span>
          <span><i className="legend-dot history" />Previous steps</span>
          <span><i className="legend-dot specific" />S boundary</span>
          <span><i className="legend-dot general" />G boundary</span>
        </div>
      </div>

      <div className="map-frame">
        <div className="map-axis-label left">SPECIFIC</div>
        <div className="map-axis-label right">GENERAL</div>
        <svg viewBox="0 0 800 300" role="img" aria-label="Interactive hypothesis space visualization with persistent step history">
          <defs>
            <linearGradient id="spaceGlow" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#23e7ff" stopOpacity=".18" />
              <stop offset="50%" stopColor="#8b5cf6" stopOpacity=".05" />
              <stop offset="100%" stopColor="#ff4fd8" stopOpacity=".18" />
            </linearGradient>
          </defs>
          <rect x="20" y="28" width="755" height="245" rx="18" fill="url(#spaceGlow)" opacity=".75" />
          {[0,1,2,3,4].map(i => <line key={i} x1={36+i*180} y1="42" x2={36+i*180} y2="262" stroke="rgba(255,255,255,.08)" strokeDasharray="3 8" />)}
          {[0,1,2,3].map(i => <line key={i} x1="36" y1={54+i*69} x2="756" y2={54+i*69} stroke="rgba(255,255,255,.055)" />)}
          {points.map(point => {
            const fill = point.special ? '#23e7ff' : point.general ? '#c084fc' : point.current ? '#a7b9d8' : '#62728f'
            const radius = point.special || point.general ? 5.8 : point.current ? 3.4 : 2.7
            const opacity = point.special || point.general ? 1 : point.current ? .68 : .28
            return (
              <g key={point.key} onClick={() => setSelected(point.key)} style={{ cursor: 'pointer' }}>
                {!point.current && <circle cx={point.x} cy={point.y} r="5.5" fill="none" stroke="#6c7d9d" strokeOpacity=".08" />}
                {(point.special || point.general) && <circle cx={point.x} cy={point.y} r="12" fill={fill} opacity=".12" />}
                <circle cx={point.x} cy={point.y} r={radius} fill={fill} opacity={opacity} />
              </g>
            )
          })}
          <line x1="36" y1="274" x2="756" y2="274" stroke="rgba(255,255,255,.18)" />
        </svg>

        {selectedPoint && (
          <div className="map-tooltip">
            <div className="tooltip-top"><b>Hypothesis</b><button onClick={() => setSelected(null)}>×</button></div>
            <code>{displayH(selectedPoint.h)}</code>
            <div className="tooltip-meta">
              <span>{selectedPoint.wildcardCount} / {names.length} wildcards</span>
              <span>{selectedPoint.current ? 'Current step' : `Visited through step ${selectedPoint.lastSeen}`}</span>
              {selectedPoint.special && <strong className="cyan">S boundary</strong>}
              {selectedPoint.general && <strong className="pink">G boundary</strong>}
            </div>
          </div>
        )}
      </div>
      <div className="visual-note">Step history is cumulative through Step {activeStep}. Older hypotheses fade rather than disappearing, so progression remains visible during replay.</div>
      {points.length < [...(steps.slice(0, activeStep + 1).flatMap(step => step.versionSpace))].length && <div className="visual-note">Showing a sampled {maxNodes}-node view for performance; Export JSON still contains the complete exact set.</div>}
    </section>
  )
}

export function BoundaryEvolution({ steps, names }) {
  const W = 800, H = 190, left = 42, right = 18, top = 28, bottom = 30
  const maxStep = Math.max(1, steps.length - 1)
  const x = step => left + (step / maxStep) * (W - left - right)
  const y = generality => top + (1 - generality) * (H - top - bottom)
  const avgGeneral = h => h.length ? h.reduce((sum, item) => sum + item.filter(v => v === '?').length / Math.max(1,names.length), 0) / h.length : 0
  const sPoints = steps.map(step => `${x(step.step)},${y(avgGeneral(step.S))}`).join(' ')
  const gPoints = steps.map(step => `${x(step.step)},${y(avgGeneral(step.G))}`).join(' ')

  return (
    <section className="evolution-card glass">
      <div>
        <div className="eyebrow">BOUNDARY EVOLUTION</div>
        <h2>How the learning window moves</h2>
        <p>Average wildcard ratio across each boundary. Moving upward means the boundary became more general.</p>
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label="S and G boundary evolution chart">
        {[0, .25, .5, .75, 1].map(v => <g key={v}><line x1={left} x2={W-right} y1={y(v)} y2={y(v)} stroke="rgba(255,255,255,.07)" /><text x="6" y={y(v)+4} fill="#6f7a90" fontSize="10">{Math.round(v*100)}%</text></g>)}
        <polyline points={sPoints} fill="none" stroke="#23e7ff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
        <polyline points={gPoints} fill="none" stroke="#c084fc" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
        {steps.map(step => <circle key={`s-${step.step}`} cx={x(step.step)} cy={y(avgGeneral(step.S))} r="3.5" fill="#23e7ff" />)}
        {steps.map(step => <circle key={`g-${step.step}`} cx={x(step.step)} cy={y(avgGeneral(step.G))} r="3.5" fill="#c084fc" />)}
        <text x={left} y={H-8} fill="#6f7a90" fontSize="10">0</text>
        <text x={W-right-12} y={H-8} fill="#6f7a90" fontSize="10">{maxStep}</text>
      </svg>
      <div className="chart-legend"><span><i className="legend-line cyan-line"/>S</span><span><i className="legend-line purple-line"/>G</span></div>
    </section>
  )
}
