import { useEffect, useMemo, useState } from 'react'

export default function MatplotlibMap({ model, active }) {
  const [image, setImage] = useState('')
  const [status, setStatus] = useState('idle')
  const [error, setError] = useState('')

  const payload = useMemo(() => ({
    datasetName: model?.datasetName || 'Imported dataset',
    step: active?.step ?? 0,
    // Plot all observed examples so the map itself retains the full training trail.
    rows: model?.rows?.map(row => ({ features: row.features, target: row.target, id: row.id })) ?? [],
    featureNames: model?.featureNames ?? [],
    targetName: model?.targetName ?? 'Target',
    S: active?.S ?? [],
    G: active?.G ?? []
  }), [model, active])

  useEffect(() => {
    if (!model || !active) return
    const controller = new AbortController()
    setStatus('loading'); setError('')
    fetch('/api/visualize', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload), signal: controller.signal })
      .then(async response => {
        const data = await response.json()
        if (!response.ok || !data.ok) throw new Error(data.error || `Visualization request failed (${response.status})`)
        return data
      })
      .then(data => { if (!controller.signal.aborted) { setImage(`data:${data.mime};base64,${data.image}`); setStatus('ready') } })
      .catch(err => { if (err.name !== 'AbortError') { setStatus('error'); setError(err.message) } })
    return () => controller.abort()
  }, [model, active, payload])

  return <section className="panel glass matplotlib-panel">
    <div className="panel-head">
      <div><div className="eyebrow">PYTHON + MATPLOTLIB ENGINE</div><h2>Automatic dataset visualization map</h2><p className="muted">The training examples stay visible while the highlighted boundary snapshot changes with the selected step.</p></div>
      <div className={`viz-status ${status}`}><span className="status-dot" />{status==='loading'?'Generating…':status==='ready'?'Matplotlib ready':status==='error'?'Visualization error':'Waiting'}</div>
    </div>
    <div className="matplotlib-frame">
      {status==='loading'&&<div className="matplotlib-loading"><div className="loader-orbit"/><b>Generating the map…</b><span>Encoding features → stable 2D projection → Matplotlib rendering</span></div>}
      {status==='error'&&<div className="matplotlib-error"><b>Python visualization could not render.</b><span>{error}</span><small>Start the project with <code>npm run dev</code> from the root folder.</small></div>}
      {image&&<img src={image} alt="Matplotlib automatic dataset visualization" className="matplotlib-image"/>}
    </div>
    <div className="matplotlib-caption"><span>Stable projection • training dots persist</span><span>Rows plotted: {Math.min(model?.rows?.length??0,5000).toLocaleString()}</span><span>Current step: {active?.step??0}</span></div>
  </section>
}
