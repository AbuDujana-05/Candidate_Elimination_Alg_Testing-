export const NULL_VALUE = '∅'
export const WILDCARD = '?'

export function isNullHypothesis(h) {
  return h.every(v => v === NULL_VALUE)
}

export function hypothesisKey(h) {
  return h.join('|')
}

export function covers(h, instance) {
  if (isNullHypothesis(h)) return false
  return h.every((value, i) => value === WILDCARD || value === instance[i])
}

export function moreGeneralOrEqual(a, b) {
  return a.every((value, i) => {
    if (value === WILDCARD) return true
    if (b[i] === NULL_VALUE) return true
    return value === b[i]
  })
}

export function strictlyMoreGeneral(a, b) {
  return moreGeneralOrEqual(a, b) && hypothesisKey(a) !== hypothesisKey(b)
}

export function moreSpecificOrEqual(a, b) {
  return moreGeneralOrEqual(b, a)
}

function dedupe(hypotheses) {
  const map = new Map()
  for (const h of hypotheses) map.set(hypothesisKey(h), h)
  return [...map.values()]
}

function minimalSpecificBoundary(S) {
  const unique = dedupe(S)
  return unique.filter((candidate, i) =>
    !unique.some((other, j) => i !== j && strictlyMoreGeneral(candidate, other))
  )
}

function maximalGeneralBoundary(G) {
  const unique = dedupe(G)
  return unique.filter((candidate, i) =>
    !unique.some((other, j) => i !== j && strictlyMoreGeneral(other, candidate))
  )
}

export function minimalGeneralizations(s, instance) {
  const h = [...s]
  let changed = false
  for (let i = 0; i < h.length; i++) {
    if (h[i] === NULL_VALUE) {
      h[i] = instance[i]
      changed = true
    } else if (h[i] !== WILDCARD && h[i] !== instance[i]) {
      h[i] = WILDCARD
      changed = true
    }
  }
  return changed ? [h] : []
}

export function minimalSpecializations(g, instance, domains) {
  const result = []
  for (let i = 0; i < g.length; i++) {
    if (g[i] !== WILDCARD) continue
    for (const value of domains[i]) {
      if (value === instance[i]) continue
      const h = [...g]
      h[i] = value
      result.push(h)
    }
  }
  return dedupe(result)
}

export function initializeBoundaries(featureCount) {
  return {
    S: [Array(featureCount).fill(NULL_VALUE)],
    G: [Array(featureCount).fill(WILDCARD)]
  }
}

export function updateBoundaries(S, G, instance, label, domains, positiveLabel = 'Yes') {
  const positive = String(label).trim().toLowerCase() === String(positiveLabel).trim().toLowerCase()

  if (positive) {
    let nextG = G.filter(g => covers(g, instance))
    const nextS = []

    for (const s of S) {
      if (covers(s, instance)) {
        nextS.push(s)
        continue
      }
      for (const h of minimalGeneralizations(s, instance)) {
        // Candidate must be no more general than at least one member of G.
        if (nextG.some(g => moreGeneralOrEqual(g, h))) nextS.push(h)
      }
    }

    return {
      S: minimalSpecificBoundary(nextS),
      G: maximalGeneralBoundary(nextG),
      action: 'positive'
    }
  }

  let nextS = S.filter(s => !covers(s, instance))
  const nextG = []

  for (const g of G) {
    if (!covers(g, instance)) {
      nextG.push(g)
      continue
    }
    for (const h of minimalSpecializations(g, instance, domains)) {
      // Candidate must be no more specific than at least one member of S.
      if (nextS.some(s => moreSpecificOrEqual(s, h))) nextG.push(h)
    }
  }

  return {
    S: minimalSpecificBoundary(nextS),
    G: maximalGeneralBoundary(nextG),
    action: 'negative'
  }
}

export function buildHypothesisSpace(domains) {
  let space = [[]]
  for (const domain of domains) {
    const next = []
    for (const prefix of space) {
      for (const value of domain) next.push([...prefix, value])
      next.push([...prefix, WILDCARD])
    }
    space = next
  }
  return space
}

export function computeVersionSpace(domains, rows, positiveLabel) {
  const H = buildHypothesisSpace(domains)
  const positiveToken = String(positiveLabel).trim().toLowerCase()
  return H.filter(h =>
    rows.every(r => {
      const actualPositive = String(r.target).trim().toLowerCase() === positiveToken
      return covers(h, r.features) === actualPositive
    })
  )
}

export function runCandidateElimination(rows, featureNames, domains, targetLabels) {
  const { S: initialS, G: initialG } = initializeBoundaries(featureNames.length)
  let S = initialS
  let G = initialG
  const allH = buildHypothesisSpace(domains)

  // Maintain the exact version space incrementally. Filtering the previous
  // version space is equivalent to checking every hypothesis against all
  // examples seen so far, while avoiding an increasingly expensive rescan.
  let versionSpace = [...allH]

  const steps = [{
    step: 0,
    row: null,
    action: 'initialize',
    S: S.map(h => [...h]),
    G: G.map(h => [...h]),
    versionSpace: [...versionSpace],
    description: 'Initialized G to the maximally general hypothesis and S to the maximally specific boundary.'
  }]

  const positiveLabel = String(targetLabels.positiveLabel).trim().toLowerCase()

  for (let i = 0; i < rows.length; i++) {
    const row = rows[i]
    const result = updateBoundaries(S, G, row.features, row.target, domains)
    S = result.S
    G = result.G
    const actualPositive = String(row.target).trim().toLowerCase() === positiveLabel
    versionSpace = versionSpace.filter(h => covers(h, row.features) === actualPositive)

    steps.push({
      step: i + 1,
      row,
      action: result.action,
      S: S.map(h => [...h]),
      G: G.map(h => [...h]),
      versionSpace: [...versionSpace],
      description: result.action === 'positive'
        ? 'Positive example: inconsistent hypotheses were removed from G; S was minimally generalized and overly-general S hypotheses were pruned.'
        : 'Negative example: inconsistent hypotheses were removed from S; G was minimally specialized and overly-specific G hypotheses were pruned.'
    })
  }

  return { S, G, steps, versionSpace, hypothesisCount: allH.length }
}

export function inferTargetLabels(values) {
  const normalized = [...new Set(values.map(v => String(v).trim()).filter(Boolean))]
  if (!normalized.length) return { positiveLabel: 'Yes', negativeLabel: 'No' }
  const yes = normalized.find(v => v.toLowerCase() === 'yes')
  const no = normalized.find(v => v.toLowerCase() === 'no')
  if (yes && no) return { positiveLabel: yes, negativeLabel: no }
  const positiveWords = new Set(['1', 'true', 'y', 'positive', 'approved', 'accept', 'accepted'])
  const positive = normalized.find(v => positiveWords.has(v.toLowerCase()))
  return {
    positiveLabel: positive ?? normalized[0],
    negativeLabel: normalized.find(v => v !== (positive ?? normalized[0])) ?? `not-${positive ?? normalized[0]}`
  }
}

export function normalizeRows(rawRows) {
  if (!rawRows.length) {
    return { rows: [], headers: [], stats: { rowsRead: 0, rowsKept: 0, missingFilled: 0, skipped: 0 } }
  }

  const sourceHeaders = Object.keys(rawRows[0])
  const headers = sourceHeaders.map(h => String(h).trim()).filter(Boolean)
  const targetKey = sourceHeaders[sourceHeaders.length - 1]
  const featureKeys = sourceHeaders.slice(0, -1)
  let missingFilled = 0
  let skipped = 0
  const rows = []

  for (const raw of rawRows) {
    const target = String(raw[targetKey] ?? '').trim()
    if (!target) {
      skipped++
      continue
    }
    const features = featureKeys.map(key => {
      const value = String(raw[key] ?? '').trim()
      if (!value) {
        missingFilled++
        return 'Unknown'
      }
      return value
    })
    rows.push({ id: rows.length + 1, features, target })
  }

  return {
    rows,
    headers,
    featureNames: headers.slice(0, -1),
    targetName: headers[headers.length - 1],
    stats: { rowsRead: rawRows.length, rowsKept: rows.length, missingFilled, skipped }
  }
}

export function datasetModel(cleaned) {
  const domains = cleaned.featureNames.map((_, i) =>
    [...new Set(cleaned.rows.map(r => r.features[i]))]
  )
  const targetLabels = inferTargetLabels(cleaned.rows.map(r => r.target))
  return {
    ...cleaned,
    domains,
    targetLabels,
    ...runCandidateElimination(cleaned.rows, cleaned.featureNames, domains, targetLabels)
  }
}

export function classifyInstance(model, features, versionSpace = model?.versionSpace ?? []) {
  if (!model || versionSpace.length === 0) {
    return {
      state: 'collapsed',
      label: null,
      majorityLabel: null,
      positiveVotes: 0,
      negativeVotes: 0,
      total: 0
    }
  }

  const positiveVotes = versionSpace.filter(h => covers(h, features)).length
  const total = versionSpace.length
  const negativeVotes = total - positiveVotes
  const majorityLabel = positiveVotes >= negativeVotes
    ? model.targetLabels.positiveLabel
    : model.targetLabels.negativeLabel

  // Candidate-Elimination's exact prediction is based on consensus across
  // the whole version space. Majority vote is exposed only as a secondary
  // teaching aid when the version space contains hypotheses that disagree.
  if (positiveVotes === total) {
    return { state: 'accepted', label: model.targetLabels.positiveLabel, majorityLabel, positiveVotes, negativeVotes, total }
  }
  if (negativeVotes === total) {
    return { state: 'rejected', label: model.targetLabels.negativeLabel, majorityLabel, positiveVotes, negativeVotes, total }
  }
  return { state: 'ambiguous', label: 'Ambiguous', majorityLabel, positiveVotes, negativeVotes, total }
}

export function flipLabel(current, labels) {
  return String(current) === String(labels.positiveLabel) ? labels.negativeLabel : labels.positiveLabel
}
