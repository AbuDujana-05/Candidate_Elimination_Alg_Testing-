from __future__ import annotations

import base64
import io
import json
import math
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

HOST = '127.0.0.1'
PORT = 8765
MAX_ROWS = 5000
PALETTE = ['#22e6ff','#c084fc','#ff77c8','#7cf29a','#ffd166','#ff8f70','#80a6ff','#c9f06b','#ff99e0','#6ff7d8']

def _to_float(value: Any) -> float | None:
    try:
        if value is None or (isinstance(value, str) and not value.strip()): return None
        return float(str(value).strip())
    except (TypeError, ValueError): return None

def _encode_column(values: list[Any]) -> tuple[np.ndarray, str]:
    numeric = [_to_float(v) for v in values]
    finite = [v for v in numeric if v is not None and math.isfinite(v)]
    if len(finite) / max(1, len(values)) >= 0.82 and len(finite) >= 2:
        median = float(np.median(finite))
        return np.array([v if v is not None and math.isfinite(v) else median for v in numeric], dtype=float), 'numeric'
    labels: dict[str, int] = {}
    encoded = []
    for value in values:
        key = str(value).strip() if value is not None else 'Unknown'
        labels.setdefault(key, len(labels))
        encoded.append(labels[key])
    return np.asarray(encoded, dtype=float), 'categorical'

def _make_projection(rows: list[dict[str, Any]], feature_names: list[str]) -> tuple[np.ndarray, str]:
    n = len(rows)
    if n == 0: return np.zeros((0, 2)), 'No rows'
    columns = [[r.get('features', [None] * len(feature_names))[j] if j < len(r.get('features', [])) else None for r in rows] for j in range(len(feature_names))]
    encoded = [_encode_column(col)[0] for col in columns]
    if not encoded:
        return np.column_stack([np.arange(n), np.zeros(n)]), 'Row order'
    X = np.column_stack(encoded).astype(float)
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    if X.shape[1] == 1:
        return np.column_stack([np.arange(n, dtype=float), X[:, 0]]), f'Row order × {feature_names[0]}'
    means = np.mean(X, axis=0)
    stds = np.std(X, axis=0)
    stds[stds < 1e-12] = 1.0
    Z = (X - means) / stds
    try:
        _, _, vh = np.linalg.svd(Z, full_matrices=False)
        coords = Z @ vh[:2].T
        return coords, 'PCA projection of standardized feature encodings'
    except np.linalg.LinAlgError:
        return Z[:, :2], 'First two standardized features'

def _hypothesis_text(h: list[Any], names: list[str]) -> str:
    return '<' + ', '.join(f'{names[i]}={h[i]}' for i in range(min(len(h), len(names)))) + '>'

def _boundary_lines(boundary: list[list[Any]], names: list[str]) -> list[str]:
    if not boundary: return ['∅  boundary collapsed']
    lines = [_hypothesis_text(h, names) for h in boundary[:5]]
    if len(boundary) > 5: lines.append(f'+ {len(boundary)-5} more')
    return lines

def _wrap_hypothesis(h: list[Any], names: list[str], width: int = 46) -> list[str]:
    text = _hypothesis_text(h, names)
    if len(text) <= width:
        return [text]
    pieces = text[1:-1].split(', ')
    lines, current = [], '<'
    for piece in pieces:
        candidate = f'{current}{piece}, '
        if len(candidate) > width and current != '<':
            lines.append(current.rstrip(', ') + ',')
            current = '  ' + piece + ', '
        else:
            current = candidate
    lines.append(current.rstrip(', ') + '>')
    return lines


def generate_map(payload: dict[str, Any]) -> str:
    rows = list(payload.get('rows') or [])[:MAX_ROWS]
    feature_names = list(payload.get('featureNames') or [])
    target_name = payload.get('targetName') or 'Target'
    dataset_name = payload.get('datasetName') or 'Dataset'
    step = int(payload.get('step', 0) or 0)
    S = payload.get('S') or []
    G = payload.get('G') or []
    coords, method = _make_projection(rows, feature_names)
    targets = [str(row.get('target', 'Unknown')) for row in rows]
    unique_targets = list(dict.fromkeys(targets))
    seen_count = max(0, min(step, len(rows)))
    current_index = seen_count - 1 if seen_count else -1

    fig = plt.figure(figsize=(15.2, 8.4), dpi=130, facecolor='#050914')
    grid = fig.add_gridspec(1, 2, width_ratios=[2.75, 1.25], wspace=0.08)
    ax = fig.add_subplot(grid[0, 0])
    panel = fig.add_subplot(grid[0, 1])
    for axis in (ax, panel):
        axis.set_facecolor('#081021')
        for spine in axis.spines.values():
            spine.set_color('#24324b')

    if len(coords):
        for idx, target in enumerate(unique_targets):
            mask = np.array([t == target for t in targets])
            c = PALETTE[idx % len(PALETTE)]
            seen_mask = mask & (np.arange(len(rows)) < seen_count)
            future_mask = mask & ~seen_mask
            if future_mask.any():
                ax.scatter(
                    coords[future_mask, 0], coords[future_mask, 1],
                    s=42 if len(rows) < 800 else 22,
                    c=c, alpha=.12, edgecolors='none', label=f'{target} • upcoming'
                )
            if seen_mask.any():
                ax.scatter(
                    coords[seen_mask, 0], coords[seen_mask, 1],
                    s=42 if len(rows) < 800 else 22,
                    c=c, alpha=.82, edgecolors='#ffffff', linewidths=.35,
                    label=target
                )
                centroid = np.mean(coords[seen_mask], axis=0)
                ax.scatter([centroid[0]], [centroid[1]], s=125, c=c, marker='x', linewidths=2, alpha=.9)

        if current_index >= 0 and current_index < len(coords):
            ax.scatter(
                [coords[current_index, 0]], [coords[current_index, 1]],
                s=235, facecolors='none', edgecolors='#ffffff', linewidths=1.2, alpha=.9, zorder=8
            )
            ax.annotate(
                f'  Current example {step}',
                (coords[current_index, 0], coords[current_index, 1]),
                xytext=(10, 10), textcoords='offset points',
                color='#ffffff', fontsize=8, fontweight='bold',
                bbox=dict(boxstyle='round,pad=.35', fc='#0b1730', ec='#3d587e', alpha=.94)
            )

    ax.set_title('Automatic Dataset Projection Map', color='#f7fbff', loc='left', fontsize=18, fontweight='bold', pad=16)
    ax.text(0, 1.012, f'{dataset_name}  •  step {step}  •  {len(rows):,} rows  •  {len(feature_names)} features', transform=ax.transAxes, color='#92a6c7', fontsize=9, va='bottom')
    ax.set_xlabel(method, color='#8da3c4', fontsize=9, labelpad=9)
    ax.set_ylabel('Second projection axis', color='#8da3c4', fontsize=9, labelpad=9)
    ax.tick_params(colors='#7185a6', labelsize=8)
    ax.grid(color='#1d2a42', alpha=.7, linewidth=.6)
    ax.set_axisbelow(True)
    if unique_targets:
        handles, labels = ax.get_legend_handles_labels()
        # Keep the legend compact; upcoming/future examples remain visually faint without dominating the legend.
        compact = []
        seen = set()
        for handle, label in zip(handles, labels):
            clean = label.split(' • upcoming')[0]
            if clean in seen or clean == '':
                continue
            seen.add(clean)
            compact.append((handle, clean))
        legend = ax.legend(
            [x[0] for x in compact], [x[1] for x in compact],
            frameon=True, facecolor='#0a1428', edgecolor='#263651',
            fontsize=8, loc='upper left', bbox_to_anchor=(0, .985), borderpad=.6,
            labelspacing=.5
        )
        for text in legend.get_texts():
            text.set_color('#eaf1ff')

    panel.axis('off')
    panel.text(.05, .95, 'CANDIDATE-ELIMINATION', color='#22e6ff', fontsize=9, fontweight='bold', transform=panel.transAxes)
    panel.text(.05, .905, 'Boundary snapshot', color='#ffffff', fontsize=18, fontweight='bold', transform=panel.transAxes)
    panel.text(.05, .855, f'Target column: {target_name}', color='#91a5c5', fontsize=9, transform=panel.transAxes)

    def draw_boundary(title, color, lines, y, fill):
        panel.text(.05, y, title, color=color, fontsize=9, fontweight='bold', transform=panel.transAxes)
        y -= .055
        if not lines:
            lines = ['∅  boundary collapsed']
        for hyp in lines[:4]:
            wrapped = _wrap_hypothesis(hyp, feature_names)
            box_height = .045 + .029 * len(wrapped)
            panel.text(
                .055, y, '\n'.join(wrapped), color='#eef6ff', fontsize=7.1,
                family='DejaVu Sans Mono', transform=panel.transAxes,
                va='top', linespacing=1.35,
                bbox=dict(boxstyle='round,pad=.42', fc=fill, ec=color, alpha=.95, linewidth=.8)
            )
            y -= box_height
        if len(lines) > 4:
            panel.text(.058, y, f'+ {len(lines)-4} more hypotheses', color='#8da3c4', fontsize=7.4, transform=panel.transAxes)
            y -= .045
        return y

    y = draw_boundary('SPECIFIC  S', '#22e6ff', S, .775, '#0c2530')
    y -= .025
    y = draw_boundary('GENERAL  G', '#c084fc', G, y, '#211a31')

    panel.text(
        .05, max(.055, y-.025),
        f'Bright dots = examples already processed.\nSoft dots = upcoming examples.\nRing = current example.\n\n{len(S)} S • {len(G)} G • {len(rows[:seen_count]):,} processed',
        color='#7185a6', fontsize=7.6, transform=panel.transAxes,
        linespacing=1.55, va='top'
    )

    fig.text(.04, .985, 'Candidate-Elimination • Matplotlib Visualization Engine', ha='left', va='top', color='#ffffff', fontsize=10, fontweight='bold')
    fig.subplots_adjust(left=.055, right=.985, bottom=.085, top=.915, wspace=.08)
    buf = io.BytesIO()
    fig.savefig(buf, format='png', facecolor=fig.get_facecolor(), bbox_inches='tight', pad_inches=.18)
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode('ascii')

class Handler(BaseHTTPRequestHandler):
    server_version='CandidateEliminationMatplotlib/1.0'
    def _headers(self, content_type='application/json'):
        self.send_header('Access-Control-Allow-Origin','*'); self.send_header('Access-Control-Allow-Headers','Content-Type'); self.send_header('Access-Control-Allow-Methods','POST, GET, OPTIONS'); self.send_header('Content-Type',content_type); self.send_header('Cache-Control','no-store')
    def do_OPTIONS(self): self.send_response(204); self._headers(); self.end_headers()
    def do_GET(self):
        if self.path=='/api/health':
            body=json.dumps({'ok':True,'service':'matplotlib'}).encode(); self.send_response(200); self._headers(); self.end_headers(); self.wfile.write(body); return
        self.send_response(404); self._headers(); self.end_headers()
    def do_POST(self):
        if self.path!='/api/visualize': self.send_response(404); self._headers(); self.end_headers(); return
        try:
            length=int(self.headers.get('Content-Length','0')); payload=json.loads(self.rfile.read(length).decode('utf-8')); image=generate_map(payload); body=json.dumps({'ok':True,'mime':'image/png','image':image}).encode()
            self.send_response(200); self._headers(); self.end_headers(); self.wfile.write(body)
        except Exception as exc:
            body=json.dumps({'ok':False,'error':str(exc)}).encode(); self.send_response(500); self._headers(); self.end_headers(); self.wfile.write(body)
    def log_message(self, fmt, *args): print(f'[Matplotlib] {self.address_string()} - {fmt % args}')

if __name__=='__main__':
    print(f'Matplotlib visualization server running at http://{HOST}:{PORT}')
    ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()
