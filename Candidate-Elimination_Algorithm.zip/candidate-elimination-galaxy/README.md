# Candidate-Elimination • Version Space Visual Lab

React + Vite + JavaScript college project with the supplied OGL Galaxy background and a local Python + Matplotlib visualization engine.

## Run in VS Code
```bash
npm install
npm run dev
```

`npm run dev` starts both:
- Vite/React UI on port 5173
- Python/Matplotlib visualization service on port 8765

## Automatic visualization
For every loaded dataset, including user-imported datasets, the app automatically sends the cleaned training rows to Python. Matplotlib generates a high-contrast 2D projection and includes the current Candidate-Elimination S/G boundary snapshot. Numeric columns remain numeric where possible; categorical columns are encoded; multi-feature datasets use an automatic PCA projection.

The figure refreshes when the selected learning step changes and after noise injection.

## Core features
- Supplied Galaxy WebGL background with mouse interaction.
- CSV/Excel/document import pipeline.
- Cleaning, target extraction, Candidate-Elimination S/G updates.
- Interactive hypothesis map and boundary-evolution visualization.
- **Matplotlib map generated automatically for every dataset.**
- Exact version-space inspection for manageable finite hypothesis spaces.
- Custom scenario testing.
- Noise injection and version-space collapse demonstration.


## Test It Yourself behavior

The Test It Yourself panel evaluates against the **final learned version space** by default. This is intentional: step 0 is the untrained hypothesis space H, where most unseen instances are expected to have mixed predictions. After training, the app starts on the final step and preloads a positive training example so the result immediately demonstrates the learned decision.

Use **Use positive example** or **Use negative example** to verify the learner on known training cases. For a genuinely unseen case, the mathematically correct result can still be **Ambiguous** when the surviving hypotheses disagree. In that case, the UI also shows a secondary majority-vote teaching aid without confusing it with Candidate-Elimination's exact consensus result.


## Credits
Done by **Abu Dujana, Nithish & Pravina**.
