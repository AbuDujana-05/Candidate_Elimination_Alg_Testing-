import { spawn, spawnSync } from 'node:child_process'
import process from 'node:process'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(fileURLToPath(new URL('..', import.meta.url)))
const pythonScript = path.join(root, 'python', 'matplotlib_server.py')
const requirementsFile = path.join(root, 'python', 'requirements.txt')
const viteEntry = path.join(root, 'node_modules', 'vite', 'bin', 'vite.js')

function runSync(command, args) {
  return spawnSync(command, args, {
    cwd: root,
    stdio: 'pipe',
    encoding: 'utf8',
    windowsHide: false
  })
}

function findPython() {
  const candidates = process.platform === 'win32'
    ? [['py', ['-3']], ['python', []]]
    : [['python3', []], ['python', []]]

  for (const [command, args] of candidates) {
    const result = runSync(command, [...args, '-c', 'import sys; print(sys.executable)'])
    if (result.status === 0 && result.stdout.trim()) {
      return { command, args }
    }
  }
  return null
}

function stopProcess(child) {
  if (!child || child.killed) return
  if (process.platform === 'win32') {
    // Windows does not reliably propagate SIGTERM to a child process tree.
    spawnSync('taskkill.exe', ['/pid', String(child.pid), '/t', '/f'], {
      cwd: root,
      stdio: 'ignore',
      windowsHide: true
    })
  } else {
    child.kill('SIGTERM')
  }
}

const python = findPython()
if (!python) {
  console.error('\nPython 3.10+ is required for the Matplotlib visualization engine. Install Python and make it available as `python` or `py -3`.\n')
  process.exit(1)
}

const matplotlibCheck = runSync(python.command, [...python.args, '-c', 'import matplotlib'])
if (matplotlibCheck.status !== 0) {
  console.log('Matplotlib is missing. Installing Python visualization dependency…')
  const install = spawnSync(python.command, [...python.args, '-m', 'pip', 'install', '-r', requirementsFile], {
    cwd: root,
    stdio: 'inherit',
    windowsHide: false
  })
  if (install.status !== 0) process.exit(1)
}

const children = []
let shuttingDown = false

// Start Python directly.
const py = spawn(python.command, [...python.args, pythonScript], {
  cwd: root,
  stdio: 'inherit',
  windowsHide: false
})
children.push(py)

py.once('error', error => {
  console.error(`\nCould not start Python visualization server: ${error.message}\n`)
  shutdown(1)
})

// IMPORTANT Windows fix:
// Do not spawn `npm.cmd` with shell:false. Node/Windows can throw EINVAL for that.
// Vite is already installed after `npm install`, so invoke Vite through Node directly.
const vite = spawn(process.execPath, [viteEntry, '--host', '0.0.0.0'], {
  cwd: root,
  stdio: 'inherit',
  windowsHide: false
})
children.push(vite)

vite.once('error', error => {
  console.error(`\nCould not start Vite: ${error.message}`)
  console.error('Run `npm install` from the project root, then run `npm run dev` again.\n')
  shutdown(1)
})

function shutdown(code = 0) {
  if (shuttingDown) return
  shuttingDown = true
  for (const child of children) stopProcess(child)
  setTimeout(() => process.exit(code), 250)
}

process.on('SIGINT', () => shutdown(0))
process.on('SIGTERM', () => shutdown(0))
process.on('exit', () => {
  for (const child of children) {
    if (child && !child.killed) stopProcess(child)
  }
})

py.on('exit', code => {
  if (!shuttingDown && code !== 0) shutdown(code ?? 1)
})
vite.on('exit', code => {
  if (!shuttingDown && code !== 0) shutdown(code ?? 1)
})
